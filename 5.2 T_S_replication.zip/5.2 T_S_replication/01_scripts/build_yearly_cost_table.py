#!/usr/bin/env python3
"""Rebuild the cleaned yearly cost table with Under65 / 65plus aggregates.

Inputs (relative to the replication package root):
  - 02_outputs/US_Estimated_Costs_CSV.csv       (raw sheet exported to CSV)
  - 03_support/phase4_groupmeans_currage_full.csv (for age-band weights)

Output:
  - 02_outputs/US_Estimated_Costs_Calculated_V2.csv (clean numeric values
    including Under65 and 65plus rows)
"""

import csv
from collections import defaultdict
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = REPO_ROOT / "02_outputs"
SUPPORT_DIR = REPO_ROOT / "03_support"

RAW_COST_CSV = OUTPUT_DIR / "US_Estimated_Costs_CSV.csv"
GROUPMEANS_FILE = SUPPORT_DIR / "phase4_groupmeans_currage_full.csv"
CLEAN_COST_CSV = OUTPUT_DIR / "US_Estimated_Costs_Calculated_V2.csv"

COST_COLUMNS = ["Initial", "Continuing", "EOL_CRC_Death", "EOL_Non_CRC_Death"]
AGE_BANDS_UNDER65 = ["45-49", "50-54", "55-59", "60-64"]
AGE_BANDS_65PLUS = ["65-69", "70-74", "75-79", "80+"]


def normalize_age_label(label: str) -> str:
    return label.replace(" years", "").strip()


def parse_currency(value: str) -> float:
    """Convert strings like ' $105,478 ' to float."""
    if value is None:
        return float("nan")
    cleaned = (
        value.replace("$", "")
        .replace(",", "")
        .replace(" ", "")
        .strip()
    )
    if cleaned == "":
        return float("nan")
    try:
        return float(cleaned)
    except ValueError:
        return float("nan")


def load_raw_costs():
    rows = []
    with RAW_COST_CSV.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            cleaned = {
                "Patient Characteristic": row["Patient Characteristic"].strip(),
                "Subgroup": row["Subgroup"].strip(),
            }
            for col in COST_COLUMNS:
                cleaned[col] = parse_currency(row[col])
            rows.append(cleaned)
    return rows


def load_age_weights():
    weights = defaultdict(float)
    with GROUPMEANS_FILE.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            band = normalize_age_label(row.get("group_value", "").strip())
            if band not in AGE_BANDS_UNDER65 and band not in AGE_BANDS_65PLUS:
                continue
            try:
                weight = float(row.get("avg_years_in_group", 0.0))
            except (TypeError, ValueError):
                continue
            weights[band] += weight
    return weights


def weighted_average(cost_map, bands, weights):
    totals = {col: 0.0 for col in COST_COLUMNS}
    total_weight = 0.0

    for band in bands:
        costs = cost_map.get(band)
        if costs is None:
            continue
        weight = weights.get(band, 0.0)
        total_weight += weight
        for col in COST_COLUMNS:
            totals[col] += costs[col] * weight

    if total_weight <= 0:
        return {col: float("nan") for col in COST_COLUMNS}
    return {col: totals[col] / total_weight for col in COST_COLUMNS}


def format_float(value: float) -> str:
    if value != value:  # NaN check
        return ""
    return f"{value:.2f}"


def main():
    if not RAW_COST_CSV.exists():
        raise SystemExit(f"Missing raw cost CSV: {RAW_COST_CSV}")
    if not GROUPMEANS_FILE.exists():
        raise SystemExit(f"Missing groupmeans CSV: {GROUPMEANS_FILE}")

    rows = load_raw_costs()
    weights = load_age_weights()

    # Lookup table for age-band costs.
    age_cost_map = {}
    for row in rows:
        if row["Patient Characteristic"] != "Age Group":
            continue
        norm = normalize_age_label(row["Subgroup"])
        age_cost_map[norm] = {col: row[col] for col in COST_COLUMNS}


    under65_costs = weighted_average(age_cost_map, AGE_BANDS_UNDER65, weights)
    plus65_costs = weighted_average(age_cost_map, AGE_BANDS_65PLUS, weights)

    aggregate_rows = []
    aggregate_rows.append(
        {
            "Patient Characteristic": "Age Group",
            "Subgroup": "Under65",
            **{col: under65_costs[col] for col in COST_COLUMNS},
        }
    )
    aggregate_rows.append(
        {
            "Patient Characteristic": "Age Group",
            "Subgroup": "65plus",
            **{col: plus65_costs[col] for col in COST_COLUMNS},
        }
    )

    # Recombine rows: keep age bands first, append aggregates, then others.
    age_rows = [row for row in rows if row["Patient Characteristic"] == "Age Group"]
    other_rows = [row for row in rows if row["Patient Characteristic"] != "Age Group"]

    ordered_rows = age_rows + aggregate_rows + other_rows

    with CLEAN_COST_CSV.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=["Subgroup", *COST_COLUMNS],
        )
        writer.writeheader()
        for row in ordered_rows:
            writer.writerow(
                {
                    "Subgroup": row["Subgroup"],
                    "Initial": format_float(row["Initial"]),
                    "Continuing": format_float(row["Continuing"]),
                    "EOL_CRC_Death": format_float(row["EOL_CRC_Death"]),
                    "EOL_Non_CRC_Death": format_float(row["EOL_Non_CRC_Death"]),
                }
            )

    print(f"Wrote {CLEAN_COST_CSV}")


if __name__ == "__main__":
    main()
