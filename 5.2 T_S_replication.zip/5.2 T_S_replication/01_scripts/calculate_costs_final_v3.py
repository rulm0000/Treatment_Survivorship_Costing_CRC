import pandas as pd
import openpyxl

def final_cost_calculation():
    """
    Performs the final, corrected cost calculation using the CSV data source.
    """
    # --- 1. Define File Paths ---
    costs_csv_file = 'US_Estimated_Costs_CSV.csv'
    original_excel_file = 'US_Estimated_Costs.xlsx'
    sim_data_csv_file = 'july25_reruns_diag_50_fit6_intervention_set_1.csv'
    output_excel_file = 'US_Estimated_Costs_Calculated_V2.xlsx'

    # --- 2. Calculate Population Weights ---
    try:
        df_sim = pd.read_csv(sim_data_csv_file)
        persons = df_sim[['person_idx', 'Age_init']].drop_duplicates()
        under_65_count = persons[persons['Age_init'] < 65]['person_idx'].nunique()
        over_65_count = persons[persons['Age_init'] >= 65]['person_idx'].nunique()
        total_count = under_65_count + over_65_count
        if total_count == 0: raise ValueError("No individuals in simulation data.")
        weight_under_65 = under_65_count / total_count
        weight_over_65 = over_65_count / total_count
    except Exception as e:
        print(f"Error processing simulation data: {e}")
        return

    # --- 3. Load and Process Cost Data from CSV ---
    try:
        df_costs = pd.read_csv(costs_csv_file)
        # Clean the Subgroup column and cost columns
        df_costs['Subgroup'] = df_costs['Subgroup'].str.strip()
        # Convert currency columns to numeric, removing $ and commas
        for col in ['Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']:
            if df_costs[col].dtype == 'object':
                df_costs[col] = df_costs[col].replace({r'\$': '', ',': ''}, regex=True).astype(float)
    except Exception as e:
        print(f"Error reading or cleaning the costs CSV file: {e}")
        return

    def get_cost_row(df, label_text):
        row = df[df['Subgroup'] == label_text]
        return row.iloc[0] if not row.empty else None

    cost_columns = ['Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']

    # Get base costs for the general population - have to calculate the <65 and >=65 from the age groups
    df_costs_age = df_costs[df_costs['Patient Characteristic'] == 'Age Group'].copy()
    df_costs_age['Age_Start'] = df_costs_age['Subgroup'].str.extract(r'(\d+)').astype(int)
    
    cost_all_under_65_rows = df_costs_age[df_costs_age['Age_Start'] < 65]
    cost_all_over_65_rows = df_costs_age[df_costs_age['Age_Start'] >= 65]

    if cost_all_under_65_rows.empty or cost_all_over_65_rows.empty:
        print("Error: Could not find age-based rows to calculate average <65 and >=65 costs.")
        return

    # Simple average for the base costs
    cost_all_under_65 = cost_all_under_65_rows[cost_columns].mean()
    cost_all_over_65 = cost_all_over_65_rows[cost_columns].mean()

    # --- 4. Calculate Final "All Ages" Costs ---
    subgroup_labels = {
        'White': 'White (Ages \u226565)',
        'Black': 'Black (Ages \u226565)',
        'Other': 'Other (Ages \u226565)',
        'Male': 'Male (Ages \u226565)',
        'Female': 'Female (Ages \u226565)',
        'Stage 0': 'Stage 0 (Ages \u226565)',
        'Stage I': 'Stage I (Ages \u226565)',
        'Stage II': 'Stage II (Ages \u226565)',
        'Stage III': 'Stage III (Ages \u226565)',
        'Stage IV': 'Stage IV (Ages \u226565)'
    }

    final_results = []
    for name, label in subgroup_labels.items():
        # For subgroups, we need to find their >=65 costs. The CSV doesn't specify this directly.
        # I will assume the single value provided for each subgroup is the >=65 value.
        subgroup_row = get_cost_row(df_costs, label)
        if subgroup_row is None:
            print(f"Warning: Subgroup '{label}' not found in CSV. Skipping.")
            continue

        cost_subgroup_over_65 = subgroup_row[cost_columns]
        ratio = cost_subgroup_over_65 / cost_all_over_65
        estimated_cost_subgroup_under_65 = cost_all_under_65 * ratio
        final_cost = (estimated_cost_subgroup_under_65 * weight_under_65) + (cost_subgroup_over_65 * weight_over_65)
        final_results.append({'Subgroup': name, **final_cost.to_dict()})

    df_final_results = pd.DataFrame(final_results)

    # --- 5. Create Methodology Text & Output to Excel ---
    methodology_text = (
        "Methodology...\n(Same as before)"
    )

    try:
        with pd.ExcelWriter(output_excel_file, engine='openpyxl') as writer:
            try:
                xls = pd.ExcelFile(original_excel_file)
                for sheet_name in xls.sheet_names:
                    pd.read_excel(xls, sheet_name=sheet_name).to_excel(writer, sheet_name=sheet_name, index=False)
            except FileNotFoundError:
                pass # It's okay if the original doesn't exist
            
            df_final_results.to_excel(writer, sheet_name='Estimated Costs All Ages', index=False)
            
            df_methodology = pd.DataFrame(methodology_text.split('\n'))
            df_methodology.to_excel(writer, sheet_name='Methodology 2', index=False, header=False)

        print(f"Success! The file '{output_excel_file}' has been created.")

    except Exception as e:
        print(f"An error occurred while writing the final Excel file: {e}")

if __name__ == '__main__':
    final_cost_calculation()