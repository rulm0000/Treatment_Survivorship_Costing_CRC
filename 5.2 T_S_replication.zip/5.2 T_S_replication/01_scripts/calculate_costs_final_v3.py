import pandas as pd
import openpyxl
from pathlib import Path

def final_cost_calculation():
    """
    Performs the final, corrected cost calculation using the CSV data source.
    """
    # --- 1. Define File Paths ---
    repo_root = Path(__file__).resolve().parents[1]
    costs_csv_file = repo_root / '02_outputs' / 'US_Estimated_Costs_CSV.csv'
    original_excel_file = repo_root / '02_outputs' / 'US_Estimated_Costs.xlsx'
    sim_data_csv_file = repo_root / '00_raw' / 'july25_reruns_diag_50_fit6_intervention_set_1.csv'
    output_excel_file = repo_root / '02_outputs' / 'US_Estimated_Costs_Calculated_V2.xlsx'
    output_csv_file = repo_root / '02_outputs' / 'US_Estimated_Costs_Calculated_V2_final.csv'

    # --- 2. Calculate Population Weights ---
    try:
        df_sim = pd.read_csv(sim_data_csv_file)
        persons = df_sim[['person_idx', 'Age_init']].drop_duplicates()
        under_65_count = persons[persons['Age_init'] < 65]['person_idx'].nunique()
        over_65_count = persons[persons['Age_init'] >= 65]['person_idx'].nunique()
        total_count = under_65_count + over_65_count
        if total_count == 0: raise ValueError("No individuals in simulation data.")
        weight_under_65 = under_65_count / total_count
        weight_over_65 = over_65_count / total_count
    except Exception as e:
        print(f"Error processing simulation data: {e}")
        return

    # --- 3. Load and Process Cost Data from CSV ---
    try:
        df_costs = pd.read_csv(costs_csv_file)
        # Forward-fill the Patient Characteristic column to handle blank cells
        df_costs['Patient Characteristic'] = df_costs['Patient Characteristic'].ffill()
        # Clean the Subgroup column and cost columns
        df_costs['Subgroup'] = df_costs['Subgroup'].str.strip()
        # Convert currency columns to numeric, removing $ and commas
        for col in ['Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']:
            if df_costs[col].dtype == 'object':
                df_costs[col] = df_costs[col].replace({r'\$': '', ',': ''}, regex=True).astype(float)
    except Exception as e:
        print(f"Error reading or cleaning the costs CSV file: {e}")
        return

    def get_cost_row(df, label_text):
        row = df[df['Subgroup'] == label_text]
        return row.iloc[0] if not row.empty else None

    cost_columns = ['Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']

    # Get base costs for the general population - identify age rows by pattern matching
    # Age rows are either in "Age Group" category OR contain "years" in Subgroup
    is_age_row = (df_costs['Patient Characteristic'] == 'Age Group') | (df_costs['Subgroup'].str.contains('years', na=False))
    df_costs_age = df_costs[is_age_row].copy()
    df_costs_age['Age_Start'] = df_costs_age['Subgroup'].str.extract(r'(\d+)').astype(int)

    cost_all_under_65_rows = df_costs_age[df_costs_age['Age_Start'] < 65]
    cost_all_over_65_rows = df_costs_age[df_costs_age['Age_Start'] >= 65]

    if cost_all_under_65_rows.empty or cost_all_over_65_rows.empty:
        print("Error: Could not find age-based rows to calculate average <65 and >=65 costs.")
        return

    # Simple average for the base costs
    cost_all_under_65 = cost_all_under_65_rows[cost_columns].mean()
    cost_all_over_65 = cost_all_over_65_rows[cost_columns].mean()

    # --- 4. Calculate Final "All Ages" Costs ---
    subgroup_labels = {
        'White': 'White (Ages \u226565)',
        'Black': 'Black (Ages \u226565)',
        'Other': 'Other (Ages \u226565)',
        'Male': 'Male (Ages \u226565)',
        'Female': 'Female (Ages \u226565)',
        'Stage 0': 'Stage 0 (Ages \u226565)',
        'Stage I': 'Stage I (Ages \u226565)',
        'Stage II': 'Stage II (Ages \u226565)',
        'Stage III': 'Stage III (Ages \u226565)',
        'Stage IV': 'Stage IV (Ages \u226565)'
    }

    final_results = []
    for name, label in subgroup_labels.items():
        # For subgroups, we need to find their >=65 costs. The CSV doesn't specify this directly.
        # I will assume the single value provided for each subgroup is the >=65 value.
        subgroup_row = get_cost_row(df_costs, label)
        if subgroup_row is None:
            print(f"Warning: Subgroup '{label}' not found in CSV. Skipping.")
            continue

        cost_subgroup_over_65 = subgroup_row[cost_columns]
        ratio = cost_subgroup_over_65 / cost_all_over_65
        estimated_cost_subgroup_under_65 = cost_all_under_65 * ratio
        final_cost = (estimated_cost_subgroup_under_65 * weight_under_65) + (cost_subgroup_over_65 * weight_over_65)
        final_results.append({'Subgroup': name, **final_cost.to_dict()})

    df_final_results = pd.DataFrame(final_results)

    # --- 5. Add age band rows to the output ---
    age_band_rows = []
    for idx, row in df_costs_age.iterrows():
        age_band_rows.append({
            'Subgroup': row['Subgroup'],
            'Initial': row['Initial'],
            'Continuing': row['Continuing'],
            'EOL_CRC_Death': row['EOL_CRC_Death'],
            'EOL_Non_CRC_Death': row['EOL_Non_CRC_Death']
        })
    df_age_bands = pd.DataFrame(age_band_rows)

    # Combine: all-ages calculations + age bands
    df_complete = pd.concat([df_final_results, df_age_bands], ignore_index=True)

    # --- 6. Output to CSV ---
    df_complete.to_csv(output_csv_file, index=False)
    print(f"Success! The file '{output_csv_file}' has been created.")

    # --- 7. Create Methodology Text & Output to Excel ---
    methodology_text = (
        "Methodology...\n(Same as before)"
    )

    try:
        with pd.ExcelWriter(output_excel_file, engine='openpyxl') as writer:
            try:
                xls = pd.ExcelFile(original_excel_file)
                for sheet_name in xls.sheet_names:
                    pd.read_excel(xls, sheet_name=sheet_name).to_excel(writer, sheet_name=sheet_name, index=False)
            except FileNotFoundError:
                pass # It's okay if the original doesn't exist

            df_complete.to_excel(writer, sheet_name='Estimated Costs All Ages', index=False)

            df_methodology = pd.DataFrame(methodology_text.split('\n'))
            df_methodology.to_excel(writer, sheet_name='Methodology 2', index=False, header=False)

        print(f"Success! The file '{output_excel_file}' has also been created.")

    except Exception as e:
        print(f"An error occurred while writing the final Excel file: {e}")

if __name__ == '__main__':
    final_cost_calculation()