import pandas as pd
import openpyxl

def calculate_costs_from_csv():
    """
    Calculates weighted-average costs using a CSV as the primary data source
    and generates a comprehensive Excel report.
    """
    # --- 1. Define File Paths ---
    costs_csv_file = 'US_Estimated_Costs_CSV.csv'
    original_excel_file_for_copying = 'US_Estimated_Costs.xlsx' # Still needed for copying old sheets
    sim_data_csv_file = 'july25_reruns_diag_50_fit6_intervention_set_1.csv'
    output_excel_file = 'US_Estimated_Costs_Calculated_V2.xlsx'

    # --- 2. Calculate Population Weights ---
    try:
        df_sim = pd.read_csv(sim_data_csv_file)
        persons = df_sim[['person_idx', 'Age_init']].drop_duplicates()
        under_65_count = persons[persons['Age_init'] < 65]['person_idx'].nunique()
        over_65_count = persons[persons['Age_init'] >= 65]['person_idx'].nunique()
        total_count = under_65_count + over_65_count
        if total_count == 0: raise ValueError("No individuals in simulation data.")
        weight_under_65 = under_65_count / total_count
        weight_over_65 = over_65_count / total_count
    except Exception as e:
        print(f"Error processing simulation data: {e}")
        return

    # --- 3. Load and Process Cost Data from CSV ---
    try:
        df_costs = pd.read_csv(costs_csv_file)
        # Clean the column that contains the labels
        label_col = df_costs.columns[1] # Assuming labels are in the second column
        df_costs[label_col] = df_costs[label_col].str.strip()
    except Exception as e:
        print(f"Error reading or cleaning the costs CSV file: {e}")
        return

    def get_cost_row(df, label_text):
        row = df[df[label_col] == label_text]
        return row.iloc[0] if not row.empty else None

    cost_columns = ['Initial', 'Continuing', 'End of Life Year of CRC Death', 'End of Life Year of Non-CRC Death']

    # Get base costs for the general population
    cost_all_under_65_row = get_cost_row(df_costs, 'All (Ages <65)')
    cost_all_over_65_row = get_cost_row(df_costs, 'All (Ages >=65)')

    if cost_all_under_65_row is None or cost_all_over_65_row is None:
        print("Error: Could not find 'All (Ages <65)' or 'All (Ages >=65)' in the CSV file.")
        return

    cost_all_under_65 = cost_all_under_65_row[cost_columns]
    cost_all_over_65 = cost_all_over_65_row[cost_columns]

    # --- 4. Calculate Final "All Ages" Costs ---
    subgroup_labels = {
        'White': 'White (Ages >=65)',
        'Black': 'Black (Ages >=65)',
        'Hispanic': 'Hispanic (Ages >=65)',
        'Other': 'Other (Ages >=65)',
        'Male': 'Male (Ages >=65)',
        'Female': 'Female (Ages >=65)',
        'Stage I': 'Stage I (Ages >=65)',
        'Stage II': 'Stage II (Ages >=65)',
        'Stage III': 'Stage III (Ages >=65)',
        'Stage IV': 'Stage IV (Ages >=65)'
    }

    final_results = []
    for name, label in subgroup_labels.items():
        subgroup_row = get_cost_row(df_costs, label)
        if subgroup_row is None:
            print(f"Warning: Subgroup '{label}' not found in CSV. Skipping.")
            continue

        cost_subgroup_over_65 = subgroup_row[cost_columns]
        ratio = cost_subgroup_over_65 / cost_all_over_65
        estimated_cost_subgroup_under_65 = cost_all_under_65 * ratio
        final_cost = (estimated_cost_subgroup_under_65 * weight_under_65) + (cost_subgroup_over_65 * weight_over_65)
        final_results.append({'Subgroup': name, **final_cost.to_dict()})

    df_final_results = pd.DataFrame(final_results)

    # --- 5. Create Methodology Text & Output to Excel ---
    methodology_text = (
        "Methodology for Calculating 'All Ages' Subgroup Costs\n"
        "============================================================\n\n"
        "Objective: To create a single, weighted-average cost for all ages for each subgroup (Race, Sex, Stage).\n\n"
        "Step 1: Calculate Population Weights\n"
        "-------------------------------------\n"
        "The simulation dataset (`july25_reruns_diag_50_fit6_intervention_set_1.csv`) was analyzed to determine the \n"
        "proportion of the population in two age brackets based on their initial age (`Age_init`).\n"
        f"- Individuals with Age < 65: {under_65_count} (Weight: {weight_under_65:.2%})\n"
        f"- Individuals with Age >= 65: {over_65_count} (Weight: {weight_over_65:.2%})\n\n"
        "Step 2: Calculate Subgroup Adjustment Ratios\n"
        "--------------------------------------------\n"
        "An adjustment ratio was calculated using data from `US_Estimated_Costs_CSV.csv`.\n"
        "Formula: Ratio = Cost(Subgroup, >=65) / Cost(All, >=65)\n\n"
        "Step 3: Estimate Subgroup Costs for the <65 Population\n"
        "--------------------------------------------------------\n"
        "The ratio was applied to the general population's <65 costs to estimate the subgroup's <65 costs.\n"
        "Formula: Estimated Cost(Subgroup, <65) = Cost(All, <65) * Ratio\n\n"
        "Step 4: Calculate the Final Weighted-Average 'All Ages' Cost\n"
        "------------------------------------------------------------\n"
        "A single 'All Ages' cost was calculated using a weighted average based on the population weights.\n"
        "Formula: Final Cost = (Estimated Cost(Subgroup, <65) * Weight(<65)) + (Cost(Subgroup, >=65) * Weight(>=65))"
    )

    try:
        with pd.ExcelWriter(output_excel_file, engine='openpyxl') as writer:
            # Copy original sheets from the old Excel file
            try:
                xls = pd.ExcelFile(original_excel_file_for_copying)
                for sheet_name in xls.sheet_names:
                    df_original_sheet = pd.read_excel(xls, sheet_name=sheet_name)
                    df_original_sheet.to_excel(writer, sheet_name=sheet_name, index=False)
            except FileNotFoundError:
                print(f"Warning: Original Excel file '{original_excel_file_for_copying}' not found. Skipping copy of old sheets.")
            
            df_final_results.to_excel(writer, sheet_name='Estimated Costs All Ages', index=False)
            
            df_methodology = pd.DataFrame(methodology_text.split('\n'))
            df_methodology.to_excel(writer, sheet_name='Methodology 2', index=False, header=False)

        print(f"Success! The file '{output_excel_file}' has been created.")

    except Exception as e:
        print(f"An error occurred while writing the final Excel file: {e}")

if __name__ == '__main__':
    calculate_costs_from_csv()
