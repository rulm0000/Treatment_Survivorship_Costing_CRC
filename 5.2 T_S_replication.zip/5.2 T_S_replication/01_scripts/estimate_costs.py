

import pandas as pd
import numpy as np
from pathlib import Path

def create_final_excel():
    try:
        # Set up paths relative to repository root
        repo_root = Path(__file__).resolve().parents[1]
        input_file = repo_root / "00_raw" / "Treatemant Survivorship cost.xlsx"
        output_file = repo_root / "02_outputs" / "US_Estimated_Costs.xlsx"

        # Load and clean original data
        df = pd.read_excel(input_file, sheet_name=0, header=1)
        df.columns = ['Patient Characteristic', 'Subgroup', 'Initial_Old', 'Continuing_Old', 'EOL_CRC_Death_Old', 'EOL_Non_CRC_Death_Old', 'Currency', 'Costing Year', 'Source', 'Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']
        for col in ['Source', 'Subgroup', 'Patient Characteristic']:
            df[col] = df[col].str.strip()

        # Separate studies
        canadian_df = df[df['Source'] == 'Garg et al., 2024'].set_index('Subgroup')
        us_df = df[df['Source'] == 'Mariotto et al., 2020'].set_index('Subgroup')

        cost_columns = ['Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']
        canadian_costs = canadian_df[cost_columns].apply(pd.to_numeric, errors='coerce')
        us_costs = us_df[cost_columns].apply(pd.to_numeric, errors='coerce')

        # --- Perform Calculations ---
        ratio_50s_vs_60s = canadian_costs.loc['50-59 years'] / canadian_costs.loc['60-69 years']
        ratio_40s_vs_60s = canadian_costs.loc['40-49 years'] / canadian_costs.loc['60-69 years']
        us_65_69_costs = us_costs.loc['65-69 years']

        estimated_costs = pd.DataFrame(columns=cost_columns, index=['45-49', '50-54', '55-59', '60-64'])
        estimated_costs.loc['55-59'] = us_65_69_costs * ratio_50s_vs_60s
        estimated_costs.loc['50-54'] = us_65_69_costs * ratio_50s_vs_60s
        estimated_costs.loc['45-49'] = us_65_69_costs * ratio_40s_vs_60s
        estimated_costs.loc['60-64'] = (estimated_costs.loc['55-59'] + us_65_69_costs) / 2
        estimated_costs = estimated_costs.round(2)
        estimated_costs.reset_index(inplace=True)
        estimated_costs.rename(columns={'index': 'Subgroup'}, inplace=True)
        estimated_costs['Patient Characteristic'] = 'Age Group'

        # --- Combine data for the new sheet ---
        us_original_data = us_df.reset_index()[[ 'Patient Characteristic', 'Subgroup', 'Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']]
        final_us_data = pd.concat([estimated_costs, us_original_data], ignore_index=True)
        final_us_data = final_us_data[['Patient Characteristic', 'Subgroup', 'Initial', 'Continuing', 'EOL_CRC_Death', 'EOL_Non_CRC_Death']]

        # --- Create Methodology Text ---
        methodology_text = (
            "Methodology for Estimating Younger Age Group Costs for the US Study\n"
            "=======================================================================\n\n"
            "The costs for US age groups under 65 were estimated using ratios derived from the Canadian study data (Garg et al., 2024) "
            "and applied to the known costs for the US 65-69 age group (Mariotto et al., 2020).\n\n"
            "1. Ratio Calculation:\n"
            "   - A '50s vs 60s Ratio' was calculated by dividing the costs for the Canadian '50-59 years' group by the '60-69 years' group.\n"
            "   - A '40s vs 60s Ratio' was calculated by dividing the costs for the Canadian '40-49 years' group by the '60-69 years' group.\n\n"
            "2. Cost Estimation:\n"
            "   - US Costs for 50-54 and 55-59: The '50s vs 60s Ratio' was multiplied by the costs of the US '65-69 years' group.\n"
            "   - US Costs for 45-49: The '40s vs 60s Ratio' was multiplied by the costs of the US '65-69 years' group.\n"
            "   - US Costs for 60-64: These were estimated by taking the average of the calculated costs for the '55-59' group and the known costs for the '65-69' group.\n\n"
            "All costs are presented in 2025 USD."
        )
        methodology_df = pd.DataFrame([methodology_text])

        # --- Write to Excel ---
        with pd.ExcelWriter(output_file, engine='xlsxwriter') as writer:
            final_us_data.to_excel(writer, sheet_name='US Study Estimated Costs', index=False)
            methodology_df.to_excel(writer, sheet_name='Methodology', index=False, header=False)

            # Auto-adjust column widths
            worksheet1 = writer.sheets['US Study Estimated Costs']
            for i, col in enumerate(final_us_data.columns):
                worksheet1.set_column(i, i, max(final_us_data[col].astype(str).map(len).max(), len(col)) + 2)
            
            worksheet2 = writer.sheets['Methodology']
            worksheet2.set_column(0, 0, 100) # Set width for methodology text

        print(f"Successfully created the Excel file: {output_file}")

    except FileNotFoundError as e:
        print(f"Error: Input file not found: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    create_final_excel()
